execute if score @s joined matches 1.. run function spleef:freshply

	# run check to make sure we arent out of bounds
	# note that this could change our zone
function spleef:intcheck

	# add dug snow to pending snow
execute if score @s dugsnow matches 1.. run function spleef:digsnow

	# if we're out of the spleef arena, add pending snow to our total
execute unless score @s zone matches 1 if score @s pendingsnow matches 1.. run function spleef:addsnow

	# update our snow bar if its incorrect
execute unless score @s hudsnow = @s snow run function spleef:updatehudsnow
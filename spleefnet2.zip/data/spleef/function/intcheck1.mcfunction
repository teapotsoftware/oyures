	# out of arena
execute positioned -10 94 -148 positioned ~-4 ~-4 ~-4 unless entity @s[dx=108,dy=60,dz=108] run function spleef:spleefloser
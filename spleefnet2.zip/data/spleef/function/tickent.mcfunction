execute as @s[type=item] run function spleef:tickitem
execute as @s[tag=!spleef] run function spleef:freshent
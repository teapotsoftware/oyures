tellraw @a [{"selector":"@s"},{"text":" got spleefed!"}]
function spleef:enterzone0
scoreboard players remove @s pendingsnow 1
scoreboard players add @s snow 1
playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.3
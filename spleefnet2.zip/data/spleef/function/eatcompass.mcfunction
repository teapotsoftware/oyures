give @s compass[item_model="minecraft:compass",consumable={},item_name={"text":"To Spawn"}]
function spleef:enterzone0
advancement revoke @s only spleef:eatcompass
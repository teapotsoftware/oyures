scoreboard players remove @s dugsnow 1

	# TODO: different shovels have different chances to add snow
execute if predicate spleef:10pct run scoreboard players add @s pendingsnow 1

	# tell the arena how much of it has been dug
scoreboard players add #total dugsnow 1

	# reset the arena if its tattered
execute if score #total dugsnow matches 1000.. run function spleef:spleefreset

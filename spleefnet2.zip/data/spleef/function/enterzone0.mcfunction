function spleef:exitzone
gamemode adventure @s
scoreboard players set @s zone 0
tp @s 138 63 91
scoreboard players set #total dugsnow 0
execute positioned -10 94 -148 run fill ~ ~ ~ ~100 ~ ~100 snow_block
tellraw @a {"text":"Arena reset!"}
	# true dummy variable used for various misc calculations
scoreboard objectives add whatever dummy

	# player zone, mostly for keeping track of intchecks
scoreboard objectives add zone dummy

	# detect players who left
scoreboard objectives add joined custom:leave_game

	# snow, basic player currency
scoreboard objectives add snow dummy

	# pending snow will fill up snow when were out of a game
scoreboard objectives add pendingsnow dummy

	# dugsnow just adds itself to pending snow
scoreboard objectives add dugsnow mined:snow_block

	# keep track of xp level to show our snow
scoreboard objectives add hudsnow level

	# keep track of player integrity check status
scoreboard objectives add intcheck dummy

	# player id, should be unique per player
scoreboard objectives add playerid dummy

	# keep track of highest playerid
	# check for an assigned value and assign 0 if there isnt one
execute store success score #isvalid playerid run scoreboard players get #highest playerid
execute if score #isvalid playerid matches 0 run scoreboard players set #highest playerid 0

	# i too like to live dangerously
gamerule maxCommandChainLength 9999999
gamerule maxCommandForkCount 9999999
gamerule randomTickSpeed 50
gamerule spawnRadius 0
gamerule doDaylightCycle false
gamerule doWeatherCycle false
gamerule doFireTick false
gamerule doMobSpawning false
gamerule doInsomnia false
gamerule doTraderSpawning false
gamerule doPatrolSpawning false
gamerule doVinesSpread false
gamerule fallDamage false

time set 700t
weather clear

bossbar add spleefarena "Spleef Arena"
bossbar set spleefarena visible true

	# generic exit zone function
execute if score @s zone matches 0 run function spleef:exitzone0
execute if score @s zone matches 1 run function spleef:exitzone1
execute if score @s zone matches 2 run function spleef:exitzone2
execute if score @s zone matches 3 run function spleef:exitzone3
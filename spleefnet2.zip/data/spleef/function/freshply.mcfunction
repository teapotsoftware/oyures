scoreboard players set @s joined 0
attribute @s minecraft:attack_speed base set 100
attribute @s minecraft:attack_damage base set -100

	# give us a player id if we dont have a valid one
execute store success score #isvalid playerid run scoreboard players get @s playerid
execute if score #isvalid playerid matches 0 run function spleef:assignid

	# welcome newbies
execute as @s[tag=!welcomed] run function spleef:welcome

	# force any combat loggers back to spawn
function spleef:enterzone0
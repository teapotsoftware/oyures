execute as @a at @s run function spleef:tickply
execute as @e[type=!player] at @s run function spleef:tickent
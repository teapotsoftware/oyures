tellraw @a [{"text":"Welcome "},{"selector":"@s"},{"text":" to the server!"}]

	# starter gear
give @s iron_shovel[tooltip_display={hidden_components:["attribute_modifiers","unbreakable","can_break"]},item_name="Rusty Shovel",unbreakable={},can_break=[{blocks:"snow_block"}],lore=[{"color":"dark_gray","italic":false,"text":"10% chance to collect snow"}]]
give @s iron_axe[tooltip_display={hidden_components:["attribute_modifiers","unbreakable","can_break"]},item_name="Rusty Axe",unbreakable={},can_break=[{blocks:"spruce_log"}]]
give @s compass[item_model="minecraft:compass",consumable={},item_name="To Spawn"]

tag @s add welcomed
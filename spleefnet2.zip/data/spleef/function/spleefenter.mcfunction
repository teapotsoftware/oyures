tellraw @a [{"selector":"@s"},{"text":" entered the arena"}]
function spleef:enterzone1
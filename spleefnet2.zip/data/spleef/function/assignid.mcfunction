scoreboard players add #highest playerid 1
execute store result score @s playerid run scoreboard players get #highest playerid
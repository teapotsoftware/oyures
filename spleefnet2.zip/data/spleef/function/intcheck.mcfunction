	# generic player integrity check function
execute if score @s zone matches 0 run function spleef:intcheck0
execute if score @s zone matches 1 run function spleef:intcheck1
execute if score @s zone matches 2 run function spleef:intcheck2
execute if score @s zone matches 3 run function spleef:intcheck3
	# send to spleef
execute if block ~ ~-1 ~ diamond_block run function spleef:spleefenter
scoreboard players remove @s dugsnow 1
scoreboard players add @s snow 1
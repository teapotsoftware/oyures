function spleef:exitzone
gamemode adventure @s
tp @s 39 126 -99
scoreboard players set @s zone 1
execute store result storage spleef snowbar int 1 run scoreboard players get @s snow
function spleef:updatehudsnow2 with storage spleef